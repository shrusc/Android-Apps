
Shruti Saligrama Chandrakantha LNU
Red Id: 8185895558

Project Description:
An app which allows users to create and share grocery lists.
Key Points:
1. Each user must sign-up with their mobile number to use the app.
2. User can create his own personal grocery list and also share lists with others.

External Frameworks used:
1. Parse framework
2. Bolts framework - provided with Parse

Some limitations:
1. The user should register with a mobile number in the US format only (xxx) xxx-xxxx.
2. The user needs to make sure that the contact number he shares the grocery list with is in the US format.